import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProdServService } from '../prod-serv.service';
import { ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
import { BehaviorSubject, Observable, config } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from "@angular/router"
import { User } from '../models/User'
import { THROW_IF_NOT_FOUND } from '@angular/core/src/di/injector';

@Component({
  selector: 'app-modify-form',
  templateUrl: './modify-form.component.html',
  styleUrls: ['./modify-form.component.css']
})
export class ModifyFormComponent implements OnInit {
  modifyForm: FormGroup
  idprod: String
  produit: any
  categories: any
  submitted = false;
  prodId: any
  nomprod: any
  prixprod: any
  descProd: any
  categProd: any
  souscat: any
  constructor(private router: Router, private cookieService: CookieService, private route: ActivatedRoute, private prodserv: ProdServService, private formBuilder: FormBuilder) {

  }
  ngOnInit() {
    if (this.cookieService.get('clientiD') != "0" || "undefined") {
      this.modifyForm = this.formBuilder.group({
        name: ['', Validators.required],
        prix: ['', Validators.required],
        description: ['', Validators.required],
        category: ['', Validators.required]
      });
      this.route.paramMap.subscribe(params => {
        this.idprod = params.get("id")
        console.log(this.idprod + " ID PROD MODIFY")
      })

      this.getProd(this.idprod);
      this.getallCateg();
    } else {
      this.router.navigate(['/login'])
    }
  }

  getSousCateg(id: String) {
    var userPreference;

    if (confirm("Do you want to delete that element? " + id) == true) {
      userPreference = "Data deleted successfully!";

    } else {
      userPreference = "Save Deletion!";
    }
    document.getElementById("confirm").innerHTML = userPreference;
  }

  getallCateg() {
    console.log("GETALLCATEGIN");
    this.prodserv.GetallCategInd().subscribe(data => {
      console.log("GETALLCATEGdata " + data);
      this.categories = data
      console.log("GETALLCATEG " + typeof (this.categories));
    });
  }
  getProd(id: String) {
    this.prodserv.GetProductSimple(id).subscribe(data => {
      console.log("getPRODMODIFY");
      this.produit = data[0];
      console.log(this.produit.name + " GETPRODMODIFY");
      this.prodId = this.produit.id
      this.nomprod = this.produit.name
      console.log(this.nomprod + " noproer")
      this.prixprod = this.produit.prix
      this.descProd = this.produit.description
      this.categProd = this.produit.categId
    });

  }

  onSubmit() {
    this.submitted = true;
    console.log("ONSUBMIT");
    console.log(this.f.name.value);
    if (this.f.name.value != "") {
      this.nomprod = this.f.name.value;
      console.log(this.nomprod + " NOMPROD MODIFY")
    }
    if (this.f.prix.value != "") {
      this.prixprod = this.f.prix.value;
      console.log(this.prixprod + " prixprod MODIFY")
    }
    if (this.f.description.value != "") {
      this.descProd = this.f.description.value;
      console.log(this.descProd + " descProd MODIFY")
    }
    if (this.f.category.value != "") {
      this.categProd = this.f.category.value;
      console.log(this.categProd + " categProd MODIFY")
    }

    this.prodserv.updateConfig(this.prodId, this.nomprod, this.descProd, this.prixprod, this.categProd)
      .subscribe(
        data2 => {
          console.log("UDATE")
        });
  }
  get f() { return this.modifyForm.controls; }

  FindSousCateg(id: String) {
    console.log("FindSousCateg");
    this.prodserv.GetCateg(id).subscribe(data => {
      console.log("findsouscategories");
      this.souscat = data;
      console.log(this.souscat);

    });
  }
}
