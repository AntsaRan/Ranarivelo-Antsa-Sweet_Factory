import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CookieService } from 'ngx-cookie-service';
import { Router, ActivatedRoute } from '@angular/router';
import { first } from 'rxjs/operators';
import { AuthentService } from '../authent.service';
import { ProdServService } from '../prod-serv.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  loginform: FormGroup;
  submitted = false;
  success = false;
  returnUrl: string;

  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthentService,
    private prodserv: ProdServService,
    private cookie: CookieService
  ) {
    if (this.authenticationService.currentUserValue) {
      this.router.navigate(['/']);
    }
  }

  ngOnInit() {
    this.cookie.set('clientiD', "0");
    this.loginform = this.formBuilder.group({
      login: ['', Validators.required],
      password: ['', Validators.required]

    });

  }
  get f() { return this.loginform.controls; }
  onSubmit() {
    this.submitted = true;
    console.log("ONSUBMIT");
    this.authenticationService.login(this.f.login.value, this.f.password.value)
      .pipe(first())
      .subscribe(
        data => {

        },
        error => {
          //this.alertService.error(error);
          //this.loading = false;
        });
  }
  logout(){
    this.authenticationService.logout();
  }
}
