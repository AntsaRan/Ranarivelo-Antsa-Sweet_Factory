export class Categorie {
    constructor(
        public id: string,
        public name: string,
    ) { }
}
