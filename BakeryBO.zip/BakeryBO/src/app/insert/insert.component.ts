import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProdServService } from '../prod-serv.service';
import { ActivatedRoute, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';

@Component({
  selector: 'app-insert',
  templateUrl: './insert.component.html',
  styleUrls: ['./insert.component.css']
})
export class InsertComponent implements OnInit {
  insertForm: FormGroup
  categories: any
  submitted = false;
  nomprod: string
  prixprod: string
  descProd: string
  categProd: string
  img:string
  constructor(private router: Router, private cookieService: CookieService, private route: ActivatedRoute, private prodserv: ProdServService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    if (this.cookieService.get('clientiD') != "0" || "undefined") {
      this.insertForm = this.formBuilder.group({
        name: ['', Validators.required],
        prix: ['', Validators.required],
        description: ['', Validators.required],
        category: ['', Validators.required],
        img: ['', Validators.required]
      });

      this.getallCateg();
    } else {
      this.router.navigate(['/login'])
    }

  }

  getSousCateg(id: String) {
    var userPreference;

    if (confirm("Do you want to delete that element? " + id) == true) {
      userPreference = "Data deleted successfully!";

    } else {
      userPreference = "Save Deletion!";
    }
    document.getElementById("confirm").innerHTML = userPreference;
  }

  getallCateg() {
    console.log("GETALLCATEGIN");
    this.prodserv.GetallCategInd().subscribe(data => {
      console.log("GETALLCATEGdata " + data);
      this.categories = data
      console.log("GETALLCATEG " + typeof (this.categories));
    });
  }

  onSubmit() {
    this.submitted = true;
    console.log("ONSUBMIT");
    console.log(this.f.name.value);
    if (this.f.name.value != "") {
      this.nomprod = this.f.prix.value;
      console.log(this.nomprod + " NOMPROD MODIFY")
    }
    if (this.f.prix.value != "") {
      this.prixprod = this.f.prix.value;
      console.log(this.prixprod + " NOMPROD MODIFY")
    }
    if (this.f.description.value != "") {
      this.descProd = this.f.description.value;
      console.log(this.descProd + " NOMPROD MODIFY")
    }
    if (this.f.category.value != "") {
      this.categProd = this.f.category.value;
      console.log(this.categProd + " NOMPROD MODIFY")
    }
    console.log(this.nomprod + " noproer");
    console.log(this.prixprod + " noproer");
    console.log(this.descProd + " noproer");
    console.log(this.categProd + " noproer");
     this.prodserv.InsertProduct(this.nomprod,this.img , this.descProd,this.prixprod, this.categProd )
       .subscribe(
         data2 => {
          this.router.navigate(['/home'])
         });
  }
  get f() { return this.insertForm.controls; }

}
