import { TestBed } from '@angular/core/testing';

import { ProdServService } from './prod-serv.service';

describe('ProdServService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ProdServService = TestBed.get(ProdServService);
    expect(service).toBeTruthy();
  });
});
