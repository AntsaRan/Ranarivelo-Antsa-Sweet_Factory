import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';  // Import it up here
import { Observable,of } from 'rxjs';
import { map } from 'rxjs/operators';
import { Categorie } from './models/categorie.model'
@Injectable({
  providedIn: 'root'
})
export class ProdServService {
  apiUrl = 'https://bakerybo.herokuapp.com';

  constructor(private http: HttpClient) { }

  GetCateg(id : String){
    return this.http.get(this.apiUrl +'/categ/'+id)   
  }

  GetCategModel(id : String):Observable<Categorie[]>{
    return this.http.get<Categorie[]>(this.apiUrl +'/categ/'+id)   
  }
  GetallCateg(){
    console.log(" getcateg");
    return this.http.get(this.apiUrl +'/allcateg')   
  }
  GetallCategInd(){
    console.log(" getcateg");
    return this.http.get(this.apiUrl +'/allcategindef')   
  }
  /* tESSSSSSSSSSSSSSSSSSSSSSSSSSST */

  GetallCategModel() :Observable<Categorie[]>{
    console.log(" getcateg");
    return this.http.get(this.apiUrl +'/allcateg').pipe(
      map((data:any[])=>data.map((item:any)=> new Categorie(
        item.id,
        item.name
      ))),
    );  
  }
  GetProducts(idsc : String){
    console.log(" getproducts");
    return this.http.get(this.apiUrl +'/products/'+idsc)   
  }

  GetProductSimple(idsc : String){
    console.log(" getproducts");
    return this.http.get(this.apiUrl +'/productSimple/'+idsc)   
  }
  GetallProducts(){
    console.log(" getallproducts");
    return this.http.get(this.apiUrl +'/products')   
  }
  
  GetCategSimple(id : String){
    console.log(" getCategSimple")
    console.log(id);
    return this.http.get(this.apiUrl +'/findcateg/'+id)   
  }

  DeleteProduct(id : String){
    console.log(" DeleteProduct")
    console.log(id);
    return this.http.get(this.apiUrl +'/deleteProd/'+id)   
  }

  InsertProduct( nom: string ,img:string, desc: string, prix: string, categ: string){
    console.log(" InsertProduct")
    return this.http.get(this.apiUrl +'/insertprod/'+nom+'/'+img+'/'+desc+'/'+prix+'/'+categ)   
  }
  updateConfig(id: string, nom: string , desc: string, prix: string, categ: string){
    return this.http.get(this.apiUrl +'/updateprod/'+ id + '/' + nom + '/' + desc +'/' + prix +'/'+ categ );
   }
}



