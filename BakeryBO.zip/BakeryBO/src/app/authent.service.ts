import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable, config } from 'rxjs';
import { map } from 'rxjs/operators';
import { Router } from "@angular/router"
import { User } from '../app/models/User'
import { CookieService } from 'ngx-cookie-service';
@Injectable({
  providedIn: 'root'
})
export class AuthentService {

  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;
  apiUrl = 'https://bakerybo.herokuapp.com';
  cookies = 'UNKNOWN';

  constructor(private http: HttpClient, private router: Router, private cookieService: CookieService) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  login(login: string, password: string) {
    console.log("LOGIN2");
    console.log(login + " user " + password + " pass");
    return this.http.get(this.apiUrl + '/authent/' + login + '/' + password)//,params.toString(),httpOptions)
      .pipe(map(user => {
        if (user['id'] != 0) {
          console.log(user + " user");
          this.cookieService.set('clientiD', user['id']);
          this.router.navigate(['/home']);
          // window.location.href="client-page.component.html";
        } else {
          console.log(user);
          alert('Login incorrect');
          this.router.navigate(['/login']);
        }
      }));
  }

  logout() {
    // remove user from local storage to log user out
    localStorage.removeItem('currentUser');
    this.currentUserSubject.next(null);
    this.cookieService.deleteAll;
    this.router.navigate(['/login']);
  }
}
