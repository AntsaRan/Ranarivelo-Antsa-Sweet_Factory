import { Component, OnInit } from '@angular/core';
import { ProdServService } from '../prod-serv.service'
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie-service';
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  constructor(private cookieService: CookieService, private router: Router,private prosdserv: ProdServService) { }
  products: any;
  ngOnInit() {
    if (this.cookieService.get('clientiD') != "0") {
      this.getProd();
    } else {
      this.router.navigate(['/login'])
    }
  }

  getProd() {
    this.prosdserv.GetallProducts().subscribe(data => {
      console.log("getProdpastries");
      this.products = data;
      console.log(this.products);
    });
  }

  ConfirmDelete(id: String) {
    var userPreference;

    if (confirm("Do you want to delete that element? " + id) == true) {
      userPreference = "Data deleted successfully!";
      this.deleteprod(id)
      window.location.reload();
    } else {
      userPreference = "Cancelled";
    }
    document.getElementById("confirm").innerHTML = userPreference;
  }
  deleteprod(id: String) {
    this.prosdserv.DeleteProduct(id).subscribe(data => {
      console.log("deleeeete");
    });
  }

  updteptod(id: String) {
    this.prosdserv.DeleteProduct(id).subscribe(data => {
      console.log("update");

    });
  }


}
