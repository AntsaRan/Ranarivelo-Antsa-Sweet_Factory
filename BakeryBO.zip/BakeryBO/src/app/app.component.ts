import { Component } from '@angular/core';
import { longStackSupport } from 'q';
import { AuthentService } from './authent.service';
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'BakeryBO';

  constructor(

    private authenticationService: AuthentService,

  ) { }


  logout() {
    this.authenticationService.logout();
  }
}

