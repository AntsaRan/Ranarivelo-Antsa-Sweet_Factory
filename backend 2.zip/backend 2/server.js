const express = require('express');
const cors = require ('cors')
const app = express();
const port = 3000;

const Prodrouter = require('./routes/products.js')
const Catrouter = require('./routes/categ.js')

app.use(Prodrouter)
app.use(Catrouter)


app.get('/', function(req, res) {
console.log(" hou")
  });
app.listen(process.env.PORT ||  5000, function(){
    console.log('Your node js server is running');
});

