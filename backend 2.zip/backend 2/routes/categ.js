//will contain all of my products related routes
const express = require('express');
const mysql = require('mysql');
const router = express.Router()
const cors = require ('cors')

const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'remotemysql.com',
    user: 'CkSNkoTyhP',
    password:'UsrFyZVCj4',
    database: 'CkSNkoTyhP'
})

function getConnection() {
    return pool
}
var request = require('request');

router.get("/categ/:id",cors(), (req, res) => {
    
    console.log("GETCATEG.js")
    const connection = getConnection()
    const categId = req.params.id
    console.log(categId)

    const queryString = "SELECT * FROM categorie WHERE idparent= ?"
    connection.query(queryString, [categId], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
         categories = rows.map((row) => {
            return { name: row.name, id: row.id }
        })

        if (categories.length == 0) {
            categories={name: "vide", id:0}
            console.log(categories.name + " categories lentgh")
            res.json(categories)
        } else {
            console.log(categories+ " categories lentgh misy")
            res.json(categories)
        }
    })
})
router.get("/findcateg/:id",cors(), (req, res) => {
  
    console.log("GETCATEG SIMPLE")
    const connection = getConnection()
    const categId = req.params.id
    console.log(categId)

    const queryString = "SELECT * FROM categorie WHERE id= ?"
    connection.query(queryString, [categId], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
        const categories = rows.map((row) => {
            return { name: row.name }
        })

        console.log(categories[0].name)
        res.json(categories[0].name)
    })
})

router.get("/allcateg",cors(), (req, res) => {
    
    console.log("Categ.js")
    const connection = getConnection()
    const categId = req.params.id
    const queryString = "SELECT * FROM categorie WHERE idparent= 0"
    console.log("après QUERY STRING")
    connection.query(queryString, (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        } else if (!rows.length) {
            res.json("no data");
            console.log("no data")
            return ("no data");
        } else {

            const categories = rows.map((row) => {
                return { name: row.name, id: row.id }
            })

            console.log(categories)
            res.json(categories)
        }
    })
})


router.get("/allcategindef",cors(), (req, res) => {
    
    console.log("Categ.js")
    const connection = getConnection()
    const categId = req.params.id
    const queryString = "SELECT * FROM categorie "
    console.log("après QUERY STRING")
    connection.query(queryString, (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        } else if (!rows.length) {
            res.json("no data");
            console.log("no data")
            return ("no data");
        } else {

            const categories = rows.map((row) => {
                return { name: row.name, id: row.id }
            })

            console.log(categories)
            res.json(categories)
        }
    })
})


module.exports = router