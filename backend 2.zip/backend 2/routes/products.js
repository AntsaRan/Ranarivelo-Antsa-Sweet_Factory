//will contain all of my products related routes
const express = require('express');
const mysql = require('mysql');
const router = express.Router()
const cors = require('cors')
router.get('/testroutes', (req, res) => {
    console.log("show me a message")
    res.end()
})

const pool = mysql.createPool({
    connectionLimit: 10,
    host: 'remotemysql.com',
    user: 'CkSNkoTyhP',
    password: 'UsrFyZVCj4',
    database: 'CkSNkoTyhP'
})

function getConnection() {
    return pool
}

router.get("/products/:id", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("GETPRODUCTS.js")
    const connection = getConnection()
    const categId = req.params.id
    console.log(categId)

    const queryString = "SELECT * FROM produit WHERE idCateg= ?"
    connection.query(queryString, [categId], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
        const categories = rows.map((row) => {
            return { name: row.name, id: row.id, prix: row.prix, description: row.Description }
        })

        console.log(categories)
        res.json(categories)
    })
})
router.get("/productSimple/:id", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("GETPRODUCTSIMPLE.js")
    const connection = getConnection()
    const prodid = req.params.id
    console.log(prodid)

    const queryString = "SELECT produit.id as Id, Description , produit.name, categorie.id as category, categorie.name as categoryName,prix  FROM produit JOIN categorie on categorie.id = produit.idCateg where produit.id=?"
    connection.query(queryString, [prodid], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
        const produit = rows.map((row) => {
            return { name: row.name, categName: row.categoryName, categId: row.category, id: row.Id, prix: row.prix, description: row.Description }
        })

        console.log(produit)
        res.json(produit)
    })
})

router.get("/products", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("GETAllPRODUCTS.js")
    const connection = getConnection()
    const categId = req.params.id
    console.log(categId)

    const queryString = "SELECT produit.id as Id, Description , produit.name, categorie.name as category,prix  FROM produit JOIN categorie on categorie.id = produit.idCateg "
    connection.query(queryString, [categId], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
        const categories = rows.map((row) => {
            return { name: row.name, categ: row.category, id: row.Id, prix: row.prix, description: row.Description }
        })

        console.log(categories)
        res.json(categories)
    })
})

router.get("/deleteProd/:id", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("deleteproduit.js")
    const connection = getConnection()
    const prodId = req.params.id
    console.log(prodId)

    const queryString = "DELETE FROM produit WHERE id = ?"
    connection.query(queryString, [prodId], (err, result) => {
        if (err) throw err;
        console.log("Number of records deleted: " + result.affectedRows);

    })
})

router.get("/updateprod/:id/:nom/:desc/:prix/:categ", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("updateproduit.js")
    const connection = getConnection()
    const prodId = req.params.id
    const prodname = req.params.nom
    const prodDesc = req.params.desc
    const prodPrix = req.params.prix
    const prodCateg = req.params.categ
     user;
    console.log(prodId + "id")
    console.log(prodname + " name")
    console.log(prodDesc + " prodDesc")
    console.log(prodPrix + " prodPrix")

    const queryString = "UPDATE produit SET name = ?, idCateg=?,description =?,prix=? WHERE id = ?"
    console.log(queryString);
    connection.query(queryString, [prodname, prodCateg, prodDesc, prodPrix, prodId], (err, result) => {
        if (err) throw err;
        console.log("Number of records deleted: " + result.affectedRows);

    })
})
router.get("/authent/:login/:password", cors(), (req, res) => {
    res.header("Access-Control-Allow-Origin", "*");
    console.log("GETUSER.js")
    const connection = getConnection()
    const log = req.params.login
    const password = req.params.password

    const queryString = "SELECT id FROM user WHERE login= ? and password =?"
    connection.query(queryString, [log, password], (err, rows, fields) => {
        if (err) {
            console.log("Failed to query for products: " + err)
            res.sendStatus(500)
            return
        }
        if (JSON.stringify(rows) == "[]") {
            user = "0"
        } else {
            user = rows.map((row) => {
                return { id: row.id }
            })
        }
        console.log(user + " USER")
        res.json(user)
    })
})

module.exports = router